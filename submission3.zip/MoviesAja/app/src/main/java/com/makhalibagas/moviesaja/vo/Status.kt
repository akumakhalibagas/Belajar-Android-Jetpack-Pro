package com.makhalibagas.moviesaja.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}