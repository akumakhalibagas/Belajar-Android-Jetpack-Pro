package com.makhalibagas.moviesaja.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}