package com.makhalibagas.moviesaja.utils

import com.makhalibagas.moviesaja.data.MoviesTvAja

interface MoviesAjaCallback {
    fun onClick(moviesTvAja: MoviesTvAja)
}