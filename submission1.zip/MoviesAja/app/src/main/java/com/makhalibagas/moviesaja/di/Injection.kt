package com.makhalibagas.moviesaja.di

class Injection {
}