package com.makhalibagas.moviesaja.utils

class EspressoIdlingResource {
}