package com.makhalibagas.moviesaja.utils

import com.makhalibagas.moviesaja.data.MoviesAja

interface MoviesAjaCallback {
    fun onClick(moviesAja: MoviesAja)
}