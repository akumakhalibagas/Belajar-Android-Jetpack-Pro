package com.makhalibagas.moviesaja.viewmodel

class ViewModelFactory {
}